
# Avel7Bet - Site de Apostas

Este é o código-fonte do site **Avel7Bet**, desenvolvido em HTML e CSS.  
Você pode usar este material para publicar seu site gratuitamente usando o GitHub Pages.

---

## ✅ O que está incluso:

- `index.html`: página principal
- `style.css`: estilo visual do site
- `README.txt`: instruções de publicação

---

## 🚀 Como colocar seu site no ar (GitHub Pages)

1. Acesse [https://github.com](https://github.com) e crie uma conta (se ainda não tiver).
2. Crie um repositório com o nome `avel7bet`.
3. Clique em **Add file** > **Upload files** e envie os arquivos `index.html` e `style.css`.
4. Clique em **Commit changes**.
5. Vá para **Settings** > **Pages**.
6. Em "Source", escolha a branch `main` e pasta `/ (root)`, depois clique em **Save**.
7. Pronto! O site estará disponível em:
   ```
   https://seuusuario.github.io/avel7bet/
   ```
   (Troque `seuusuario` pelo seu nome de usuário no GitHub)

---

## 💻 Visualizar localmente

1. Extraia os arquivos do ZIP.
2. Clique duas vezes em `index.html` para abrir no navegador.

---

© 2025 Avel7Bet. Todos os direitos reservados.
